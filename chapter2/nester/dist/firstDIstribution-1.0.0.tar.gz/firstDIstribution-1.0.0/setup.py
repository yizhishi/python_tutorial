#setup.py
from distutils.core import setup

setup(
    name = 'firstDIstribution',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'yizhishi',
    author_email = '283620911@qq.com',
    url = 'https://github.com/yizhishi',
    description = 'first distribution',
)
